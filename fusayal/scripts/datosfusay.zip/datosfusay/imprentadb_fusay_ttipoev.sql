INSERT INTO fusay.ttipoev (tiev_id, tiev_nombre, tiev_img) VALUES (1, 'Ceremonia de Medicina', 'medancestral_prod.jpg');
INSERT INTO fusay.ttipoev (tiev_id, tiev_nombre, tiev_img) VALUES (2, 'Temazcal', 'temazcal_prod.jpg');
INSERT INTO fusay.ttipoev (tiev_id, tiev_nombre, tiev_img) VALUES (3, 'Danza', 'reiki_prod.jpeg');
INSERT INTO fusay.ttipoev (tiev_id, tiev_nombre, tiev_img) VALUES (4, 'Baño', 'terapiasal_prod.jpeg');
INSERT INTO fusay.ttipoev (tiev_id, tiev_nombre, tiev_img) VALUES (5, 'Congreso', 'congreso.png');