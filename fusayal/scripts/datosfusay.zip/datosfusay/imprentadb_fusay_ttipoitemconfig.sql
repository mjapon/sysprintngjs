INSERT INTO fusay.ttipoitemconfig (tipic_id, tipic_nombre, tipic_estado) VALUES (1, 'PRODUCTO', 1);
INSERT INTO fusay.ttipoitemconfig (tipic_id, tipic_nombre, tipic_estado) VALUES (2, 'SERVICIO', 1);
INSERT INTO fusay.ttipoitemconfig (tipic_id, tipic_nombre, tipic_estado) VALUES (3, 'CUENTA CONTABLE', 1);