INSERT INTO fusay.tauditaccion (taa_id, taa_accion) VALUES (1, 'Creación');
INSERT INTO fusay.tauditaccion (taa_id, taa_accion) VALUES (2, 'Actualización');
INSERT INTO fusay.tauditaccion (taa_id, taa_accion) VALUES (3, 'Eliminación');
INSERT INTO fusay.tauditaccion (taa_id, taa_accion) VALUES (4, 'Acceso');