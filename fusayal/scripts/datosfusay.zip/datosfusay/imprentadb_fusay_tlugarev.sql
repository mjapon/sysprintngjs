INSERT INTO fusay.tlugarev (lugc_id, lugc_nombre) VALUES (1, 'CENTRO CEREMONIAL SARAGURO');
INSERT INTO fusay.tlugarev (lugc_id, lugc_nombre) VALUES (2, 'CASA DEL WIKI CUENCA');