INSERT INTO fusay.tclasecontrib (cls_id, cls_nombre) VALUES (1, 'PERSONA NATURAL');
INSERT INTO fusay.tclasecontrib (cls_id, cls_nombre) VALUES (2, 'EXTRANJERO');
INSERT INTO fusay.tclasecontrib (cls_id, cls_nombre) VALUES (3, 'CONTRIBUYENTE ESPECIAL');
INSERT INTO fusay.tclasecontrib (cls_id, cls_nombre) VALUES (4, 'CONTRIBUYENTE RISE');
INSERT INTO fusay.tclasecontrib (cls_id, cls_nombre) VALUES (5, 'CONTRIBUYENTE REGIMEN SIMPLIFICADO');