INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (1, 'FACTURA');
INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (2, 'NOTA DE CRÉDITO');
INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (3, 'NOTA DE DÉBITO');
INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (4, 'GUÍA DE REMISIÓN');
INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (5, 'COMPROBANTE DE RETENCIÓN');
INSERT INTO fusay.ttiposdoc (td_id, td_nombre) VALUES (6, 'LIQUIDACION DE COMPRAS');