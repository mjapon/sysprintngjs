INSERT INTO fusay.tserviciomedico (tsm_id, med_id, serv_id) VALUES (1, 12, 27);
INSERT INTO fusay.tserviciomedico (tsm_id, med_id, serv_id) VALUES (2, 10, 28);
INSERT INTO fusay.tserviciomedico (tsm_id, med_id, serv_id) VALUES (3, 7, 28);