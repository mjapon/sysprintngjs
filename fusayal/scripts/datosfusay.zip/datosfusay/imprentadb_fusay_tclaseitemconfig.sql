INSERT INTO fusay.tclaseitemconfig (clsic_id, clsic_abreviacion, clsic_nombre, clsic_estado) VALUES (1, 'A', 'ACTIVO', 1);
INSERT INTO fusay.tclaseitemconfig (clsic_id, clsic_abreviacion, clsic_nombre, clsic_estado) VALUES (2, 'P', 'PASIVO', 1);
INSERT INTO fusay.tclaseitemconfig (clsic_id, clsic_abreviacion, clsic_nombre, clsic_estado) VALUES (3, 'I', 'INGRESO', 1);
INSERT INTO fusay.tclaseitemconfig (clsic_id, clsic_abreviacion, clsic_nombre, clsic_estado) VALUES (4, 'G', 'GASTO', 1);