INSERT INTO fusay.tgrid (grid_id, grid_nombre, grid_basesql, grid_columnas, grid_fechacrea, grid_tupladesc) VALUES (2, 'tickets', ' select
                a.tk_id,
                a.tk_nro,
                a.tk_dia,
                   p.per_nombres||'' ''||p.per_apellidos as per_nomapel,
                   p.per_ciruc,
                   p.per_email,
                   a.tk_costo,
                   a.tk_estado
            from ttickets a
            join tpersona p on a.tk_perid = p.per_id
            where a.tk_dia = ''{tk_dia}'' and a.sec_id={sec_id} and a.tk_estado=1 order by  a.tk_nro', '[
    {"label":"Nro", "field":"tk_nro"},
    {"label":"Nombres y Apellidos", "field":"per_nomapel"},
    {"label":"#Cedula", "field":"per_ciruc"},
    {"label":"Email", "field":"per_email"},
    {"label":"Costo", "field":"tk_costo"}    
]', '2020-03-06 20:38:17.000000', '["tk_id", "tk_nro", "tk_dia", "per_nomapel", "per_ciruc", "per_email", "tk_costo", "tk_estado"]');
INSERT INTO fusay.tgrid (grid_id, grid_nombre, grid_basesql, grid_columnas, grid_fechacrea, grid_tupladesc) VALUES (1, 'productos', 'select ic.ic_id,
       ic.ic_nombre,
       ic.ic_code,
       ic_nota,
       t.tipic_nombre,
       dp.icdp_grabaiva,
       case dp.icdp_grabaiva when true then ''SI'' else ''NO'' end AS grabaiva,
       dp.icdp_preciocompra,
       case dp.icdp_grabaiva when true then round(PONER_IVA(dp.icdp_preciocompra),2)
        else dp.icdp_preciocompra end as preciocompraiva,
       dp.icdp_precioventa,
       case dp.icdp_grabaiva when true then round(PONER_IVA(dp.icdp_precioventa),2)
        else dp.icdp_precioventa end as precioventaiva,
       dp.icdp_precioventamin,
       dp.icdp_fechacaducidad,
       coalesce(ice.ice_stock, 0) as ice_stock
       from titemconfig ic
join titemconfig_datosprod dp on dp.ic_id = ic.ic_id
join ttipoitemconfig t on ic.tipic_id = t.tipic_id
left join titemconfig_stock ice on ic.ic_id = ice.ic_id and ice.sec_id = {sec_id}
where ic.ic_estado = 1 and ({where}) order by {order}', '[
    {"label":"Código Barra", "field":"ic_code"},    
    {"label":"Iva", "field":"grabaiva"},    
    {"label":"Pr Compra(Iva)", "field":"preciocompraiva"},
    {"label":"Pr Venta(Iva)", "field":"precioventaiva"},    
    {"label":"Fecha caducidad", "field":"icdp_fechacaducidad"},
    {"label":"Stock", "field":"ice_stock"}
]', '2020-02-15 21:24:49.000000', '["ic_id", "ic_nombre", "ic_code", "ic_nota", "tipic_nombre", "icdp_grabaiva", "grabaiva", "icdp_preciocompra","preciocompraiva", "icdp_precioventa","precioventaiva", "icdp_precioventamin", "icdp_fechacaducidad", "ice_stock"]');