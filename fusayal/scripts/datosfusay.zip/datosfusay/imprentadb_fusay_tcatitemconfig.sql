INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (1, 'NINGUNO', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (2, 'ABARROTES', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (3, 'INSUMOS MÉDICOS', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (4, 'UTILES ESCOLARES', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (5, 'PRODUCTOS DE ASEO', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (6, 'ACIETES', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (7, 'VIDEOJUEGOS', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (8, 'LAPTOS', 1);
INSERT INTO fusay.tcatitemconfig (catic_id, catic_nombre, catic_estado) VALUES (9, 'TELEMEDICINA', 1);