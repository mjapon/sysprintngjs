INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (1, 'CONTRIBUYENTES');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (2, 'EMPRESA');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (3, 'AUTORIZACIONES');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (4, 'TRABAJOS DE IMPRESION');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (5, 'USUARIOS');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (6, 'ROLESUSUARIOS');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (7, 'DOCUMENTO');
INSERT INTO fusay.ttabla (tbl_id, tbl_nombre) VALUES (8, 'PLANTILLAS');