INSERT INTO fusay.tseccion (sec_id, sec_nombre, sec_estado) VALUES (1, 'SARAGURO', 1);
INSERT INTO fusay.tseccion (sec_id, sec_nombre, sec_estado) VALUES (2, 'CUENCA', 1);