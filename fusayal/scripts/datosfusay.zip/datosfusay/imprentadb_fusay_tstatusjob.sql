INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (1, 'Nuevo');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (3, 'Incompleto');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (5, 'Reimpresion');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (2, 'Reportado');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (6, 'Impreso');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (4, 'Anulado');
INSERT INTO fusay.tstatusjob (sjb_id, sjb_nombre) VALUES (7, 'Elije Plantilla');